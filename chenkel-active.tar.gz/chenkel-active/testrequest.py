import requests

url = "https://chenkel183.api-us1.com/api/3/lists"

response = requests.request("GET", url)

print(response.text)