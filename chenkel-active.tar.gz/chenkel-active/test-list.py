import requests
import json
from config.config import ac_url, key
list_url = "https://chenkel183.api-us1.com/api/3/list/add"
data = {'List': 'List1',
        'name': 'Test List 1',
        'sender_name': 'John Doe',
        'sender_addr1': '12345. IL',
        'sender_city': 'Chicago',
        'sender_zip': '123456',
        'sender_country': 'US'
        }
header = {'Content-type': 'application/json'}

class List(ChenkelActive):


        def __init__(self, url, api_key):
                self.url = url
                self.api_key = api_key
                ChenkelActive.__init__(self, url, api_key)

        def add(self, params, post_data):
                request_url = '%s&api_action=list_add&api_output=%s' % (self.url, self.output)
        post_data = urllib.urlencode(post_data)
        req = urllib2.Request(request_url, post_data)
        response = json.loads(urllib2.urlopen(req).read())
        return response


r = requests.post(list_url, data=json.dumps(data), headers=header)
print(r.json)


if __name__ == '__main__':
    ac = ChenkelActive(ac_url, key)






# from configparser import ConfigParser
# config = ConfigParser()
# config.read('config.cfg')
# key = config.get('auth', 'key')
# url = config.get('endpoint', 'test')
# headers = {'Authorization': 'Bearer {}'.format(key)}